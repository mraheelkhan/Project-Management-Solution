<!-- Content Header (Page header) -->
<section class="content-header">
      <h1>
        Dashboard
      </h1>
      
    </section><?php /**PATH C:\xampp\htdocs\myerp\resources\views/layouts/partials/contentheader.blade.php ENDPATH**/ ?>