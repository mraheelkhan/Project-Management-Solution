<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
    <script>
      $( document ).ready(function() {
        swal("Success", "<?php echo e(session('success')); ?>", "success");
      });
      
    </script>
<?php endif; ?>
<?php if(session('failed')): ?>
    <script>
      $( document ).ready(function() {
        swal("Failed", "<?php echo e(session('failed')); ?>", "error");
      });
      
    </script>
<?php endif; ?>

<div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Manage Staff</h3>
              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-staff')): ?>
              <span class="pull-right">
              <a href="<?php echo url('/admins/create');; ?>" class="btn btn-info"><span class="fa fa-plus"></span> Add New Staff</a>
              </span>
              <?php endif; ?>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
            <?php if(count($users) > 0): ?>
              <table id="example1" class="display responsive nowrap" style="width:100%">
                <thead>
                <tr>
                  <th>Id</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Phone Number</th>
                  <th>Designation</th>
                  <th>Department</th>
                  <th>Role</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($user['id']); ?></td>
                    <td><?php echo e($user['fname']); ?> <?php echo e($user['lname']); ?></td>
                    <td><?php echo e($user['email']); ?></td>
                    <td><?php echo e($user['phonenumber']); ?></td>
                    <td><?php echo e($user['designation']['name']); ?></td>
                    <td><?php echo e($user['department']['deptname']); ?></td>
                    <td><?php echo e($user['role']['role_title']); ?></td>
                    <td>
                      <?php if($user['status'] === 1): ?>
                      <span class="label label-success">Active</span>
                      <?php else: ?>
                      <span class="label label-danger">Deactive</span>
                      <?php endif; ?>
                    </td>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-staff')): ?>
                     <!-- For Delete Form begin -->
                    <form id="form<?php echo e($user['id']); ?>" action="<?php echo e(action('UserController@destroy', $user['id'])); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input name="_method" type="hidden" value="DELETE">
                    </form>
                    <!-- For Delete Form Ends -->
                    <?php endif; ?>
                    <td>
                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show-staff')): ?><a href="<?php echo url('/admins/'.$user['id']);; ?>" class="btn btn-primary" title="View Detail"><i class="fa fa-eye"></i> </a><?php endif; ?>
                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-staff')): ?><a href="<?php echo url('/admins/'.$user['id'].'/edit');; ?>"  class="btn btn-success" title="Edit"><i class="fa fa-edit"></i> </a><?php endif; ?>
                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('status-staff')): ?>
                        <?php if($user['status'] === 1): ?>
                          <a href="<?php echo url('/admins/deactivate/'.$user['id']);; ?>"  class="btn btn-warning" title="Deactivate"><i class="fa fa-times"></i> </a>
                        <?php else: ?>
                          <a href="<?php echo url('/admins/active/'.$user['id']);; ?>"  class="btn btn-info" title="Active"><i class="fa fa-check"></i> </a>
                        <?php endif; ?>
                      <?php endif; ?>
                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-staff')): ?><button class="btn btn-danger" onclick="archiveFunction('form<?php echo e($user['id']); ?>')"><i class="fa fa-trash"></i></button><?php endif; ?>
                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('staff-reset-password')): ?><a href="<?php echo url('/admins/resetpassword/'.$user->id);; ?>"  class="btn btn-info" title="Reset Password"><i class="fa fa-key"></i> </a><?php endif; ?>
                    </td>                   

                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                <tr>
                  <th>Id</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Phone Number</th>
                  <th>Designation</th>
                  <th>Department</th>
                  <th>Role</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
                </tfoot>
              </table>
              <?php else: ?>
              <div>No Record found.</div>
              <?php endif; ?>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->   

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myerp\resources\views/admins.blade.php ENDPATH**/ ?>