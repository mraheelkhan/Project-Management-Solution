<?php
$user = Auth::user();
$permissions=explode(",",$user->role->permission);
?>
<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">

<!-- sidebar: style can be found in sidebar.less -->
<section class="sidebar">

  <!-- Sidebar user panel (optional) -->
  <div class="user-panel">
    <div class="pull-left image">
      <img src="<?php echo e(asset('public/img/staff/'.$user->avatar)); ?>" class="img-circle" alt="User Image">
    </div>
    <div class="pull-left info">
      <p><?php echo e($user->fname); ?> <?php echo e($user->lname); ?></p>
      <!-- <p>Super Admin</p> -->
    </div>
  </div>
  <?php $urlpath=Request::path();  ?>
  <!-- Sidebar Menu -->
  <ul class="sidebar-menu" data-widget="tree">
    <li class="header">NAVIGATION</li>
    <?php if(count($navs) > 0): ?>
      <?php $__currentLoopData = $navs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(count($nav->childrenformenu) > 0): ?>
         <?php if(in_array($nav->id,$permissions) &&  $nav->showinnav==1): ?>
            <li class="treeview <?php echo e((strpos($nav->mselect,$urlpath) !== false || strpos($nav->mselect, Route::currentRouteName()) !== false  )  ? "active" : ""); ?>">
              <a href="#"><i class="<?php echo e($nav->iconclass); ?>"></i> <span><?php echo e($nav->menutitle); ?> </span>
                <span class="pull-right-container">
                    <i class="fa fa-angle-left pull-right"></i>
                  </span>
              </a>
                <?php if(! empty ($nav->childrenformenu)): ?>
                  <ul class="treeview-menu">
                  <?php $__currentLoopData = $nav->childrenformenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childnav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(in_array($childnav->id,$permissions) && $childnav->showinnav==1): ?>
                    <li class="<?php echo e((strpos($childnav->mselect,$urlpath) !== false || strpos($childnav->mselect, Route::currentRouteName()) !== false  )  ? "active" : ""); ?>"><a href="<?php echo url($childnav->urllink);; ?>"><?php echo e($childnav->menutitle); ?>

                      </a></li>
                    <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                <?php endif; ?>
            </li> 
          <?php endif; ?>

        <?php else: ?>
          <?php if(in_array($nav->id,$permissions)  && $nav->showinnav==1): ?>
            <li  class="<?php echo e(strpos($nav->mselect,$urlpath)  !== false ? "active" : ""); ?>"><a href="<?php echo url($nav->urllink);; ?>"><i class="<?php echo e($nav->iconclass); ?>"></i> <span><?php echo e($nav->menutitle); ?></span></a></li>
          <?php endif; ?>
        <?php endif; ?>
        
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  
    <?php endif; ?>
    <li>
          <a href="<?php echo e(route('logout')); ?>"
                  onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();">
          <i class="fa fa-sign-out"></i> <span>Logout</span>
        </a>
      </li>
  </ul>
  <!-- /.sidebar-menu -->
</section>
<!-- /.sidebar -->
</aside><?php /**PATH C:\xampp\htdocs\myerp\resources\views/layouts/partials/leftnav.blade.php ENDPATH**/ ?>