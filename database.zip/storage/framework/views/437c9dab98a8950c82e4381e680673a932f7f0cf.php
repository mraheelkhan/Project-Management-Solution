<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
    <script>
      $( document ).ready(function() {
        swal("Success", "<?php echo e(session('success')); ?>", "success");
      });
      
    </script>
<?php endif; ?>
<?php if(session('failed')): ?>
    <script>
      $( document ).ready(function() {
        swal("Failed", "<?php echo e(session('failed')); ?>", "error");
      });
      
    </script>
<?php endif; ?>
<?php
 $user = Auth::user();
?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myerp\resources\views/dashboard.blade.php ENDPATH**/ ?>