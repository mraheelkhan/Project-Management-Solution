<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <!-- CSRF Token -->
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <meta name="user-id" content="<?php echo e(Auth::check() ? Auth::user()->id : ''); ?>">
  <title><?php echo e(config('app.name', 'NSOL ERP')); ?></title>
  <link rel="icon" href="<?php echo e(asset('img/favicon.png')); ?>" type="image/png">

  <?php echo $__env->make('layouts.partials.headerscripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
<!-- Include header bar -->
 <?php echo $__env->make('layouts.partials.topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Include left side bar -->
<?php echo $__env->make('layouts.partials.leftnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
<!-- Include content header -->
  <?php echo $__env->make('layouts.partials.contentheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Main content -->
    <section class="content container-fluid">    
        <?php echo $__env->yieldContent('content'); ?>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Include main footer -->
  <?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Include Right sidebar for setting if required -->
  <?php echo $__env->make('layouts.partials.rightsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>
<!-- ./wrapper -->

<!-- Include Footer scripts -->
<?php echo $__env->make('layouts.partials.footerscripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldPushContent('scripts'); ?>

</body>
</html><?php /**PATH C:\xampp\htdocs\myerp\resources\views/layouts/mainlayout.blade.php ENDPATH**/ ?>